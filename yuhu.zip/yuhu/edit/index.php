<?php
include("../m.php");
session_start();
//print_r($_SESSION);
$data=get($_SESSION['data']['nim']);//film
$datas=get1($_SESSION['data']['nim']);//wisata
//print_r($datas);
// echo $data[0]['nama'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">EDIT PROFIL</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="1.php">

                        <div class="form-row">
                            <div class="name">Nama</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="nama" 
                                    value="<?php echo $data[0]['nama'] ?>">
                                </div>
                            </div>
                        </div>
                        <input class="input--style-5" type="text" name="nim" value="<?php echo $data[0]['nim'] ?> "hidden>

                        <div class="form-row">
                            <div class="name">username</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="username"
                                    value="<?php echo $data[0]['username'] ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">pasword</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="pasword" name="pass"
                                    value="<?php echo $data[0]['pass'] ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Re-pasword</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="pasword" name="repass">
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="email" name="email"
                                    value="<?php echo $data[0]['email'] ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Kelas</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="kelas" name="kelas"
                                    value="<?php echo $data[0]['kelas'] ?>">
                                </div>
                            </div>
                        </div>

                      <div class="form-row">
                            <div class="name">Hobi</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="hobi" name="hobi"
                                    value="<?php echo $data[0]['hobi'] ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Tanggal Lahir</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="ttl" name="ttl"
                                    value="<?php echo $data[0]['ttl'] ?>">
                                </div>
                            </div>
                        </div>
<!-- ///////////////////////////////////////////////////////////////////////////////////////////////////////         -->
<?php
$c=[];
$c1=[];
for($i=0;$i<count($data);$i++){
if($data[$i]['film']=="Horor"){
    $c[0]="checked";
}
if($data[$i]['film']=="Romance"){
    $c[1]="checked";
}
if($data[$i]['film']=="Sci-Fi"){
    $c[2]="checked";
}
}

for($i=0;$i<count($datas);$i++){
if($datas[$i]['wisata']=="Bali"){
    $c1[0]="checked";
}
if($datas[$i]['wisata']=="Lombok"){
    $c1[1]="checked";
}
if($datas[$i]['wisata']=="Palu"){
    $c1[2]="checked";
}}

?>
<!-- ///////////////////////////////////////////////////////////////////////////////////////////////////////         -->
                        <div class="form-row p-t-20">
                            <label class="label label--block">Film</label>
                            <div class="p-t-15">
                                <label class="radio-container m-r-55">Horor
                                        <input type="checkbox" name="film[]" value="Horor" <?php if(isset($c[0]))echo $c[0] ?> >
                                     
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container m-r-55">Romance
                                        <input type="checkbox" name="film[]" value="Romance" <?php if(isset($c[1]))echo $c[1] ?>>
                                       
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container">Sci-Fi
                                        <input type="checkbox" name="film[]" value="Sci-Fi" <?php if(isset($c[2]))echo $c[2] ?>>
                                        <span class="checkmark"></span>
                                    </label>
                            </div>
                        </div>

                        <div class="form-row p-t-20">
                            <label class="label label--block">Wisata</label>
                            <div class="p-t-15">
                                <label class="radio-container m-r-55">Bali
                                        <input type="checkbox" name="wisata[]" value="Bali" <?php if(isset($c1[0]))echo $c1[0] ?> >
                                     
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container m-r-55">Lombok
                                        <input type="checkbox" name="wisata[]" value="Lombok" <?php if(isset($c1[1]))echo $c1[1] ?>>
                                       
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container">Palu
                                        <input type="checkbox" name="wisata[]" value="Palu" <?php if(isset($c1[2]))echo $c1[2] ?>>
                                        <span class="checkmark"></span>
                                    </label>
                            </div>
                        </div>

                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->