<?php
include("../m.php");

// $nama= $_POST['nama'];
// $nim=$_POST['nim'];
// $username=$_POST['username'];
// $pass=$_POST['pass'];
// $repass=$_POST['repass'];
// $email=$_POST['email'];
// print_r($_POST);

	# code...

if(empty($_POST['nama'])||empty($_POST['nim'])||empty($_POST['username'])||empty($_POST['pass'])||empty($_POST['repass'])||empty($_POST['email'])){
	echo "<script>alert('DATA HARUS DIISI')</script>";
	header("refresh:0; URL='index.php'");
}
else{
$nama= $_POST['nama'];
$nim=$_POST['nim'];
$username=$_POST['username'];
$pass=$_POST['pass'];
$repass=$_POST['repass'];
$email=$_POST['email'];
$film= $_POST['film'];
$wisata=$_POST['wisata'];
$hobi=$_POST['hobi'];
$kelas=$_POST['kelas'];
$ttl=$_POST['ttl'];
$stat='valid';
// print_r($_POST);

 if(strlen(trim($username))>20){
echo "<script>alert('USERNAME MAX 10 DIGIT')</script>";
$stat='unvalid';
	header("refresh:0; URL='index.php'");
}

if(strlen(trim($pass))<6){
echo "<script>alert('PASSWORD MIN 6 DIGIT')</script>";
$stat='unvalid';
	header("refresh:0; URL='index.php'");
}
elseif (trim($pass)!=trim($repass)) {
	# code...
	echo "<script>alert('PASSWORD TIDAK MATCH')</script>";
	$stat='unvalid';
	header("refresh:0; URL='index.php'");
}

if(strlen(trim($nama))>25){
	echo "<script>alert('NAMA 25 DIGIT')</script>";
	$stat='unvalid';
	header("refresh:0; URL='index.php'");
}


if($stat=='valid'){
	
	 echo "<script>alert('DATA ANDA TELAH DIDAFTAR')</script>";
	
	 print_r($_POST);
	 updates($nama,$nim,$username,$pass,$email,$film,$wisata,$hobi,$kelas,$ttl);
	
	
}

}


?>