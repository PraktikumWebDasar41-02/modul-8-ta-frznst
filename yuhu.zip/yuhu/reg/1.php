<?php
include("../m.php");

// $nama= $_POST['nama'];
// $nim=$_POST['nim'];
// $username=$_POST['username'];
// $pass=$_POST['pass'];
// $repass=$_POST['repass'];
// $email=$_POST['email'];
// print_r($_POST);

	# code...

if(empty($_POST['nama'])||empty($_POST['nim'])||empty($_POST['username'])||empty($_POST['pass'])||empty($_POST['repass'])||empty($_POST['email'])){
	echo "<script>alert('DATA HARUS DIISI')</script>";
	header("refresh:0; URL='index.html'");
}
else{
$nama= $_POST['nama'];
$nim=$_POST['nim'];
$username=$_POST['username'];
$pass=$_POST['pass'];
$repass=$_POST['repass'];
$email=$_POST['email'];
$stat='valid';
// print_r($_POST);

if(is_numeric(trim($nim))==false){
echo "<script>alert('NIM HARUS ANGKA')</script>";
	$stat='unvalid';
	header("refresh:0; URL='index.html'");
}
else if(strlen(trim($nim))!=10){
echo "<script>alert('NIM HARUS 10 DIGIT')</script>";
$stat='unvalid';
	header("refresh:0; URL='index.html'");
}

 if(strlen(trim($username))>20){
echo "<script>alert('USERNAME MAX 10 DIGIT')</script>";
$stat='unvalid';
	header("refresh:0; URL='index.html'");
}

if(strlen(trim($pass))<6){
echo "<script>alert('PASSWORD MIN 6 DIGIT')</script>";
$stat='unvalid';
	header("refresh:0; URL='index.html'");
}
elseif (trim($pass)!=trim($repass)) {
	# code...
	echo "<script>alert('PASSWORD TIDAK MATCH')</script>";
	$stat='unvalid';
	header("refresh:0; URL='index.html'");
}

if(strlen(trim($nama))>25){
	echo "<script>alert('NAMA 25 DIGIT')</script>";
	$stat='unvalid';
	header("refresh:0; URL='index.html'");
}


if($stat=='valid'){
	if(cek($nim,$username)==TRUE){
		echo "<script>alert('NIM ATAU USERNAME SUDAH TERDAFTAR')</script>";
		//header("refresh:0; URL='index.html'");
	}
	else{
	 echo "<script>alert('DATA ANDA TELAH DIDAFTAR')</script>";
	
	insert($nama,trim($nim),trim($username),trim($pass),$email);
	header("refresh:0; URL='../login'");
}
	
}

}


?>