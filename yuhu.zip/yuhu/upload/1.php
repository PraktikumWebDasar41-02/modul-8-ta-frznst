<?php
include("../m.php");

// $nama= $_POST['nama'];
// $nim=$_POST['nim'];
// $username=$_POST['username'];
// $pass=$_POST['pass'];
// $repass=$_POST['repass'];
// $email=$_POST['email'];
// print_r($_POST);

	# code...
session_start();
if(empty( $_POST['film'])||empty($_POST['wisata'])||empty($_POST['hobi'])||empty($_POST['kelas'])){
	echo "<script>alert('ANDA TIDAK MENGINPUT DATA')</script>";
	header("refresh:0; URL='index.html'");
}
else{
	$film= $_POST['film'];
	$wisata=$_POST['wisata'];
	$hobi=$_POST['hobi'];
	$kelas=$_POST['kelas'];
	$ttl=$_POST['ttl'];
	$nim=$_SESSION['data']['nim'];
	 echo "<script>alert('DATA BERHASIL DIUPDATE')</script>";
	 update($nim,$film,$wisata,$hobi,$kelas,$ttl);
	 //echo $nim;
	 //print_r($_POST);
	//insert($nama,trim($nim),trim($username),trim($pass),$email);
	
}


?>