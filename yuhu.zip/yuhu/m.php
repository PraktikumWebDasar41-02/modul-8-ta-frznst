<?php
$conn = mysqli_connect("localhost","root","","mhs");
// if ($conn) {
	# code...


function insert($nama,$nim,$username,$pass,$email)
{
	# code...
 GLOBAL $conn;
 mysqli_query($conn,"INSERT INTO data(nim,pass,username,nama,email) VALUES('$nim','$pass','$username','$nama','$email')");
}
function cek($nim,$username)
{
	# code...
	GLOBAL $conn;
	$query=mysqli_query($conn,"SELECT * FROM data WHERE nim='$nim' OR username='$username'");
	$hasil=mysqli_num_rows($query);
	if($hasil>0){
		return true;
	}
	else{
		return false;
	}
}

function login($a,$b)
{
	# code...
 GLOBAL $conn;
 $query=mysqli_query($conn,"SELECT nim,username,pass,nama FROM data WHERE username='$a' AND pass='$b'");
 $hasil=mysqli_num_rows($query);
 
	if ($hasil>0) {
		# code...
		$data =mysqli_fetch_array($query);
		return $data;
	}
	else{
		return false;
	}
}

function update($nim,$film,$wisata,$hobi,$kelas,$ttl)
{
	# code...
 GLOBAL $conn;
 $query1=mysqli_query($conn,"UPDATE data set kelas='$kelas', hobi='$hobi',ttl='$ttl' WHERE nim='$nim' ");
 
for($i=0; $i<count($film); $i++){
$query2=mysqli_query($conn,"INSERT INTO film values('$nim','$film[$i]') ");
//echo $film[$i]."<br>";
}
for($i=0; $i<count($wisata); $i++){
	$query3=mysqli_query($conn,"INSERT INTO wisata values('$nim','$wisata[$i]') ");
	//echo $wisata[$i]."<br>";
	}
 //echo"aaa";
}
function get($nim)
{
	# code...
GLOBAL $conn;
 $hasil=[];
 $query=mysqli_query($conn,"SELECT * FROM film INNER JOIN data using(nim) where nim='$nim'");
 for($i=0;$i<mysqli_num_rows($query);$i++){
 $hasil[$i]=mysqli_fetch_assoc($query);
 } 
return $hasil;
}

function get1($nim)
{
	# code...
GLOBAL $conn;
 $hasil1=[];
 $query1=mysqli_query($conn,"SELECT * FROM wisata where nim='$nim'");
 for($i=0;$i<mysqli_num_rows($query1);$i++){
 $hasil1[$i]=mysqli_fetch_assoc($query1);
 }
 
return $hasil1;
}

function updates($nama,$nim,$username,$pass,$email,$film,$wisata,$hobi,$kelas,$ttl)
{
	# code...
 GLOBAL $conn;
 $query1=mysqli_query($conn,"UPDATE data set
  nama='$nama',username='$username',pass='$pass',email='$email',
  kelas='$kelas', hobi='$hobi',ttl='$ttl' WHERE nim='$nim' ");

mysqli_query($conn,"DELETE FROM film where nim='$nim'");
mysqli_query($conn,"DELETE FROM wisata where nim='$nim'");
 
for($i=0; $i<count($film); $i++){
$query2=mysqli_query($conn,"INSERT INTO film values('$nim','$film[$i]') ");
//echo $film[$i]."<br>";
}
for($i=0; $i<count($wisata); $i++){
	$query3=mysqli_query($conn,"INSERT INTO wisata values('$nim','$wisata[$i]') ");
	//echo $wisata[$i]."<br>";
	}
 //echo"aaa";
}





?>