-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2018 at 03:14 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mhs`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `nim` varchar(10) NOT NULL,
  `pass` varchar(6) NOT NULL,
  `username` varchar(20) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `email` text NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `hobi` varchar(20) NOT NULL,
  `ttl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`nim`, `pass`, `username`, `nama`, `email`, `kelas`, `hobi`, `ttl`) VALUES
('6701174081', '123456', 'firzamaulananasution', 'akuu', 'firzamaulananasution@rocketmail.com', '', '', '0000-00-00'),
('6701174082', 'zazaza', 'za', 'FirzaM', 'a@g.com', '4100', 'Tidur', '2018-10-29'),
('6701174084', '123456', 'asa', 'rew', 'ad@g.vom', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `nim` varchar(10) NOT NULL,
  `film` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`nim`, `film`) VALUES
('6701174082', 'Horor'),
('6701174082', 'Romance');

-- --------------------------------------------------------

--
-- Table structure for table `wisata`
--

CREATE TABLE `wisata` (
  `nim` varchar(10) NOT NULL,
  `wisata` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wisata`
--

INSERT INTO `wisata` (`nim`, `wisata`) VALUES
('6701174082', 'Bali'),
('6701174082', 'Palu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD KEY `nim` (`nim`);

--
-- Indexes for table `wisata`
--
ALTER TABLE `wisata`
  ADD KEY `nim` (`nim`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `film_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `data` (`nim`);

--
-- Constraints for table `wisata`
--
ALTER TABLE `wisata`
  ADD CONSTRAINT `wisata_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `data` (`nim`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
