<?php
include("../m.php");
session_start();

if(empty($_POST['username'])||empty($_POST['pass'])){
	echo "<script>alert('DATA HARUS DIISI')</script>";
	header("refresh:0; URL='index.html'");
}

else{
$username=$_POST['username'];
$pass=$_POST['pass'];
$data=login($username,$pass);

// print_r($data);
 if(strlen(trim($username))>20){
echo "<script>alert('USERNAME MAX 10 DIGIT')</script>";
	header("refresh:0; URL='index.html'");
}

if(strlen(trim($pass))<6){
echo "<script>alert('PASSWORD MIN 6 DIGIT')</script>";
	header("refresh:0; URL='index.html'");
}
else if($data==false){
	echo "<script>alert('USERNAME DAN PASSWORD SALAH')</script>";
	print_r($data);
	header("refresh:0; URL='index.html'");
	
}

else{
	$_SESSION['data']=$data;
	echo "<script>alert('Halo ".$_SESSION['data']['nama']."')</script>";
	 
	print_r( $_SESSION['data']);
	
	 //print_r($_SESSION);
	//insert($nama,trim($nim),trim($username),trim($pass),$email);
	
}

}



?>